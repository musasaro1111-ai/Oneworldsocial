# ONEWORLD Social

A responsive social-network starter built with React, Vite and Supabase.

## Included in this first build
- Email sign-up and sign-in through Supabase Auth
- Public member profiles
- Create and view text posts
- Realtime feed refresh
- Initial database schema for stories, messages, follows and post likes
- Responsive desktop and mobile layout

## Setup

1. Create a Supabase project.
2. In Supabase, open **SQL Editor → New query**.
3. Paste all of `supabase/schema.sql` and click **Run**.
4. In the project root, create a file named `.env` using `.env.example` as the template.
5. Add your Supabase project URL and **publishable key**:
   - `VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co`
   - `VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_KEY`
6. Install and run:
   - `npm install`
   - `npm run dev`
7. Deploy the repository using Vercel. Add the same two environment variables in Vercel project settings.

## Security
Only use the Supabase **publishable** key in browser code. Never place a Supabase secret/service-role key in this repository or frontend. Keep Row Level Security enabled.

## Current scope
This is the foundation, not a finished clone of every social network. Stories upload, full direct messaging UI, video hosting, calls, livestreaming, comments, moderation, notifications and creator payments require separate implementation and (for media/live features) storage/streaming services.
