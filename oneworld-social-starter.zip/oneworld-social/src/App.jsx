import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import {
  Globe2, Home, Compass, MessageCircle, Bell, UserRound, Search,
  ImagePlus, Video, Heart, MessageSquare, Share2, Bookmark,
  LogOut, Menu, X, Send, Plus, Radio, Users, Play, Sparkles
} from 'lucide-react';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = (supabaseUrl && supabaseKey) ? createClient(supabaseUrl, supabaseKey) : null;

const demoPosts = [
  { id: 'demo-1', author_name: 'ONEWORLD Community', handle: '@oneworld', body: 'Welcome to ONEWORLD — a place to share ideas, meet people and build communities across borders. 🌍', created_at: new Date().toISOString(), likes_count: 128, comments_count: 24 },
  { id: 'demo-2', author_name: 'Creator Studio', handle: '@creatorstudio', body: 'Your voice matters. Share a thought, a photo, a short video or start a community. This is your world.', created_at: new Date(Date.now()-3600000).toISOString(), likes_count: 76, comments_count: 12 }
];

function timeAgo(value) {
  const mins = Math.max(1, Math.floor((Date.now() - new Date(value).getTime()) / 60000));
  if (mins < 60) return `${mins}m`;
  if (mins < 1440) return `${Math.floor(mins/60)}h`;
  return `${Math.floor(mins/1440)}d`;
}

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState(demoPosts);
  const [tab, setTab] = useState('Home');
  const [draft, setDraft] = useState('');
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [liked, setLiked] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!supabase || !session?.user) return;
    loadProfile();
    loadPosts();
    const channel = supabase.channel('public-posts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'posts' }, loadPosts)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [session]);

  async function loadProfile() {
    const user = session.user;
    const { data } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
    if (data) setProfile(data);
    else {
      const fallback = { id: user.id, username: user.email?.split('@')[0] || 'member', full_name: user.user_metadata?.full_name || 'New member' };
      const { data: created } = await supabase.from('profiles').upsert(fallback).select().single();
      setProfile(created || fallback);
    }
  }

  async function loadPosts() {
    const { data, error } = await supabase.from('posts')
      .select('id, body, media_url, media_type, created_at, user_id, profiles(username, full_name, avatar_url)')
      .order('created_at', { ascending: false }).limit(40);
    if (!error && data) setPosts(data.map(p => ({
      ...p, author_name: p.profiles?.full_name || 'ONEWORLD member',
      handle: '@' + (p.profiles?.username || 'member'), likes_count: 0, comments_count: 0
    })));
  }

  async function authenticate(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    if (!supabase) { setNotice('Connect your Supabase project first using the .env settings.'); setBusy(false); return; }
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } })
      : await supabase.auth.signInWithPassword({ email, password });
    if (result.error) setNotice(result.error.message);
    else if (authMode === 'signup') setNotice('Account created. Check your email if confirmation is enabled, then sign in.');
    setBusy(false);
  }

  async function publishPost(e) {
    e.preventDefault();
    if (!draft.trim()) return;
    if (!session) { setNotice('Sign in to publish a post.'); return; }
    const { error } = await supabase.from('posts').insert({ user_id: session.user.id, body: draft.trim() });
    if (error) setNotice(error.message);
    else { setDraft(''); setNotice('Your post is live.'); await loadPosts(); }
  }

  async function signOut() { await supabase?.auth.signOut(); setProfile(null); setTab('Home'); }

  const navItems = [
    { name: 'Home', icon: Home }, { name: 'Explore', icon: Compass },
    { name: 'Messages', icon: MessageCircle }, { name: 'Notifications', icon: Bell },
    { name: 'Communities', icon: Users }, { name: 'Profile', icon: UserRound }
  ];

  const visiblePosts = posts.filter(p => !searchTerm || `${p.body} ${p.author_name}`.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="mobile-toggle icon-btn" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Menu">{mobileMenu ? <X/> : <Menu/>}</button>
        <a className="brand" href="#" onClick={e => {e.preventDefault(); setTab('Home');}}>
          <span className="brand-mark"><Globe2 size={24}/></span><span>ONE<span>WORLD</span></span>
        </a>
        <div className="top-search"><Search size={18}/><input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search people, posts and communities"/></div>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setTab('Messages')} aria-label="Messages"><MessageCircle/></button>
          <button className="icon-btn" onClick={() => setTab('Notifications')} aria-label="Notifications"><Bell/></button>
          {session ? <button className="avatar" onClick={() => setTab('Profile')}>{(profile?.full_name || session.user.email || 'U').slice(0,1).toUpperCase()}</button> : <button className="sign-in-small" onClick={() => document.getElementById('auth-card')?.scrollIntoView({behavior:'smooth'})}>Sign in</button>}
        </div>
      </header>

      <div className="layout">
        <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
          <div className="side-label">YOUR SPACE</div>
          {navItems.map(({name, icon: Icon}) => <button key={name} className={`nav-item ${tab===name?'active':''}`} onClick={() => {setTab(name);setMobileMenu(false);}}><Icon size={20}/><span>{name}</span>{name==='Notifications' && <i className="nav-dot"/>}</button>)}
          <div className="side-divider"/>
          <div className="side-label">DISCOVER</div>
          <button className="nav-item" onClick={() => setTab('Video')}><Play size={20}/><span>Short videos</span></button>
          <button className="nav-item" onClick={() => setTab('Live')}><Radio size={20}/><span>Live</span></button>
          <button className="nav-item" onClick={() => setTab('Bookmarks')}><Bookmark size={20}/><span>Saved</span></button>
          <div className="sidebar-bottom"><div className="world-card"><Sparkles size={18}/><b>One world. Infinite connections.</b><p>Share your world with everyone.</p></div>{session && <button className="nav-item logout" onClick={signOut}><LogOut size={19}/> Sign out</button>}</div>
        </aside>

        <main className="main-content">
          <div className="welcome-row"><div><div className="eyebrow">THE WORLD, CONNECTED</div><h1>{tab === 'Home' ? 'Your world starts here.' : tab}</h1><p>People, ideas and communities — all in one place.</p></div><div className="online-pill"><span/> Global community</div></div>

          {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')}>×</button></div>}

          {!session && <section className="auth-card" id="auth-card">
            <div className="auth-copy"><div className="eyebrow">JOIN THE CONVERSATION</div><h2>One account.<br/>A world of possibilities.</h2><p>Create your account to publish, connect and take part in communities.</p></div>
            <form onSubmit={authenticate} className="auth-form">
              <div className="auth-switch"><button type="button" className={authMode==='login'?'chosen':''} onClick={() => setAuthMode('login')}>Sign in</button><button type="button" className={authMode==='signup'?'chosen':''} onClick={() => setAuthMode('signup')}>Create account</button></div>
              {authMode==='signup' && <input value={fullName} onChange={e=>setFullName(e.target.value)} placeholder="Your full name" required/>}
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address" required/>
              <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password (minimum 6 characters)" minLength="6" required/>
              <button className="primary-btn" disabled={busy}>{busy?'Please wait…':authMode==='login'?'Sign in':'Create my account'} <Send size={16}/></button>
              <small>By continuing, you agree to use ONEWORLD respectfully and lawfully.</small>
            </form>
          </section>}

          {tab === 'Home' && <div className="content-grid">
            <section className="feed-column">
              <div className="stories-card"><div className="section-heading"><div><h3>Moments</h3><p>Quick updates from your world</p></div><span className="coming-soon">COMING SOON</span></div>
                <div className="story-row"><button className="story add-story"><span><Plus/></span><b>Your moment</b></button>{['Discover','Creators','Community','Around you'].map((s,i)=><button className="story" key={s}><span className={`story-ring ring-${i}`}><Globe2/></span><b>{s}</b></button>)}</div>
              </div>
              <form className="composer card" onSubmit={publishPost}>
                <div className="composer-top"><div className="avatar big">{profile?.full_name?.slice(0,1).toUpperCase() || 'Y'}</div><textarea value={draft} onChange={e=>setDraft(e.target.value)} placeholder={session ? "What's happening in your world?" : "Sign in to share what's happening in your world…"} rows="2"/></div>
                <div className="composer-bottom"><div className="composer-tools"><button type="button" onClick={()=>setNotice('Photo and video uploads are the next development step.')}><ImagePlus/> Photo</button><button type="button" onClick={()=>setNotice('Video publishing is coming in the next development step.')}><Video/> Video</button></div><button className="primary-btn post-btn" type="submit"><Plus size={16}/> Publish</button></div>
              </form>
              <div className="feed-heading"><h3>Global feed</h3><button onClick={loadPosts}>Latest ↓</button></div>
              {visiblePosts.map(post=><article className="post-card card" key={post.id}><div className="post-head"><div className="avatar">{post.author_name?.slice(0,1).toUpperCase() || 'O'}</div><div className="post-author"><b>{post.author_name}</b><span>{post.handle} · {timeAgo(post.created_at)}</span></div><button className="more-btn">···</button></div><p className="post-body">{post.body}</p>{post.media_url && <img className="post-media" src={post.media_url} alt="Post attachment"/>}<div className="post-stats"><span>{post.likes_count || 0} appreciations</span><span>{post.comments_count || 0} comments</span></div><div className="post-actions"><button className={liked.includes(post.id)?'liked':''} onClick={()=>setLiked(prev=>prev.includes(post.id)?prev.filter(x=>x!==post.id):[...prev,post.id])}><Heart size={18}/>{liked.includes(post.id)?'Appreciated':'Appreciate'}</button><button onClick={()=>setNotice('Comments are being added in the next development step.')}><MessageSquare size={18}/> Comment</button><button onClick={()=>setNotice('Sharing will be enabled in the next development step.')}><Share2 size={18}/> Share</button><button onClick={()=>setNotice('Saved items will be enabled in the next development step.')}><Bookmark size={18}/></button></div></article>)}
              {visiblePosts.length===0 && <div className="empty card">No posts found. Try another search.</div>}
            </section>
            <aside className="right-column"><div className="card side-panel"><div className="section-heading"><h3>Explore ONEWORLD</h3><Compass size={18}/></div>{[{icon:Play,title:'Short videos',desc:'Vertical videos and creator clips'},{icon:Users,title:'Communities',desc:'Find people who share your interests'},{icon:Radio,title:'Live rooms',desc:'Real-time conversations and streams'}].map(({icon:Icon,title,desc})=><button className="explore-link" key={title} onClick={()=>setTab(title==='Short videos'?'Video':title==='Live rooms'?'Live':'Communities')}><span className="explore-icon"><Icon/></span><span><b>{title}</b><small>{desc}</small></span></button>)}</div><div className="card side-panel"><h3>Built for everyone</h3><p className="muted">A new social space bringing familiar ways to connect into one shared experience.</p><div className="feature-tags"><span>Connect</span><span>Create</span><span>Discover</span><span>Belong</span></div></div><div className="footer-links">About · Privacy · Terms · Help<br/>© 2026 ONEWORLD</div></aside>
          </div>}

          {tab !== 'Home' && <section className="placeholder card"><div className="placeholder-icon"><Globe2 size={30}/></div><div className="eyebrow">ONEWORLD FEATURE</div><h2>{tab} is in development.</h2><p>We're building this feature as part of the unified social platform. The account system and core feed are the first foundation.</p><button className="primary-btn" onClick={()=>setTab('Home')}>Back to home</button></section>}
        </main>
      </div>
      <nav className="mobile-nav">{[{name:'Home',icon:Home},{name:'Explore',icon:Compass},{name:'Messages',icon:MessageCircle},{name:'Notifications',icon:Bell},{name:'Profile',icon:UserRound}].map(({name,icon:Icon})=><button key={name} className={tab===name?'active':''} onClick={()=>setTab(name)}><Icon size={20}/><span>{name}</span></button>)}</nav>
    </div>
  );
}
